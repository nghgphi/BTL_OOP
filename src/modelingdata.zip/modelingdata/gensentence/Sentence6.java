package modelingdata.gensentence;

import java.text.MessageFormat;
//import java.util.ListIterator;
//import java.util.Scanner;
//
//import readFileCSV.StockInfo;

import modelingdata.stockinfo.StockInfo;

public class Sentence6 extends Sentence {
	
	double percent = 0.0;
	double ceil, floor;
	
	@Override
	public void process(String CodeStock, String Date) {
//		st.StockInfoList = st.getData();
		int i = 0;
		
		StockInfo temp = new StockInfo();
		
		
		while (!st.stockInfoList.get(i).getCodeStock().equals(CodeStock))
			i++;
		while (!st.stockInfoList.get(i).getDate().equals(Date))
			i++;
		
		temp = st.stockInfoList.get(i);
		ceil = st.stockInfoList.get(i+1).getClosePrice() * 1.07;
		floor = st.stockInfoList.get(i+1).getClosePrice() * 0.93;
		
//		System.out.println(i);
		
		if(st.stockInfoList.get(i).getClosePrice() > st.stockInfoList.get(i + 1).getClosePrice()) {
			if ((ceil <= 10.00 && ceil - temp.getClosePrice() < 0.01)
					|| (ceil > 10 && ceil < 10.05 && temp.getClosePrice() == 10)
					|| (ceil >= 10.05 && ceil <= 50 && ceil - temp.getClosePrice() < 0.05)
					|| (ceil > 50 && ceil < 50.10 && temp.getClosePrice() == 50)
					|| (ceil >= 50.10 && ceil - temp.getClosePrice() < 0.1)) {
				getSentence("6up");
				percent = -100 + st.stockInfoList.get(i).getClosePrice() / st.stockInfoList.get(i + 1).getClosePrice() * 100;
				String result = MessageFormat.format(str, Date, CodeStock, temp.getClosePrice(), Math.round(temp.getVolume() * 100.0) / 100.0, percent);
				saveSentence(result, "sentences");
			}
		}
			
		else if(st.stockInfoList.get(i).getClosePrice() < st.stockInfoList.get(i + 1).getClosePrice()) {
			if ((floor < 10 && - floor + temp.getClosePrice() < 0.01)
					|| (floor >= 10 && floor < 50 && - floor + temp.getClosePrice() < 0.05)
					|| (floor >= 50 && - floor + temp.getClosePrice() < 0.1)) {
				getSentence("6down");
				percent = 100 - st.stockInfoList.get(i).getClosePrice() / st.stockInfoList.get(i + 1).getClosePrice() * 100;
				String result = MessageFormat.format(str, Date, CodeStock, temp.getClosePrice(), Math.round(temp.getVolume() * 100.0) / 100.0, percent);
				saveSentence(result, "sentences");
			}
		}
		
//		String result = MessageFormat.format(str, Date, CodeStock, temp.getClosePrice(), Math.round(temp.getVolume() * 100.0) / 100.0, percent);
//		saveSentence(result, "sentence6");
	}
}


