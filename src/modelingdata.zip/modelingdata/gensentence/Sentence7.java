package modelingdata.gensentence;

import java.text.MessageFormat;

import modelingdata.stockinfo.StockInfo;

//import java.util.ListIterator;
//import java.util.Scanner;
//
//import readFileCSV.StockInfo;
import java.lang.Math;

public class Sentence7 extends Sentence {
	@Override
	public void process(String CodeStock, String Date) {
//		st.stockInfoList = st.getData();
		int i = 0;
		double percentDiff = 0.0, percentFinal = 0.0;
		StockInfo temp = new StockInfo();
		
		while (!st.stockInfoList.get(i).getCodeStock().equals(CodeStock))
			i += 123;
		while (!st.stockInfoList.get(i).getDate().equals(Date))
			i++;
		
		temp = st.stockInfoList.get(i);
		
		if(st.stockInfoList.get(i).getClosePrice() > st.stockInfoList.get(i + 1).getClosePrice() 
				&& st.stockInfoList.get(i).getLowPrice() < st.stockInfoList.get(i + 1).getClosePrice()) {
			getSentence("7toGreen");
			percentDiff = 100 - st.stockInfoList.get(i).getLowPrice()/st.stockInfoList.get(i + 1).getClosePrice() * 100;
			percentFinal = -100 + st.stockInfoList.get(i).getClosePrice() / st.stockInfoList.get(i + 1).getClosePrice() * 100;
			String result = MessageFormat.format(str, Date, CodeStock, percentDiff, percentFinal, Math.round(temp.getVolume()/100000.0 * 100.0) / 100.0, 1000 * (st.stockInfoList.get(i).getClosePrice() - st.stockInfoList.get(i+1).getClosePrice()));
			saveSentence(result, "sentences");
		}
			
		else if(st.stockInfoList.get(i).getClosePrice() < st.stockInfoList.get(i + 1).getClosePrice()
				&& st.stockInfoList.get(i).getHighPrice() > st.stockInfoList.get(i + 1).getClosePrice()) {
			getSentence("7toRed");
			percentDiff = -100 + st.stockInfoList.get(i).getHighPrice() / st.stockInfoList.get(i + 1).getClosePrice() * 100;
			percentFinal = 100 - st.stockInfoList.get(i).getClosePrice() / st.stockInfoList.get(i + 1).getClosePrice() * 100;
			String result = MessageFormat.format(str, Date, CodeStock, percentDiff, percentFinal, Math.round(temp.getVolume()/100000.0 * 100.0) / 100.0, 1000 * (- st.stockInfoList.get(i).getClosePrice() + st.stockInfoList.get(i+1).getClosePrice()));
			saveSentence(result, "sentences");
		}
	}
}


