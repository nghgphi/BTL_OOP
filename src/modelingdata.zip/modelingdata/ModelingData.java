package modelingdata;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import modelingdata.gensentence.Sentence;
import modelingdata.gensentence.Sentence1;
import modelingdata.gensentence.Sentence10;
import modelingdata.gensentence.Sentence12;
import modelingdata.gensentence.Sentence2;
import modelingdata.gensentence.Sentence3;
import modelingdata.gensentence.Sentence4;
import modelingdata.gensentence.Sentence5;
import modelingdata.gensentence.Sentence6;
import modelingdata.gensentence.Sentence7;
import modelingdata.gensentence.Sentence9;
import modelingdata.readfilecsv.FileInfo;
import modelingdata.stockinfo.StockList;

public class ModelingData {
	List<Sentence> Sentences;
	FileInfo Inf;
	
	public ModelingData() {
		Sentences = new ArrayList<>();
		Inf = new FileInfo();
		Sentence.st = new StockList();
		Sentence.st.setData(Inf.getStockInfoList()); 
		
		Sentences.add(new Sentence9());
		Sentences.add(new Sentence10());
		Sentences.add(new Sentence12());
		Sentences.add(new Sentence5());
		Sentences.add(new Sentence6());
		Sentences.add(new Sentence7());
		Sentences.add(new Sentence1());
		Sentences.add(new Sentence2());
		Sentences.add(new Sentence3());
		Sentences.add(new Sentence4());
	}
	
	public void processData(String date, int month, String codeStock) {
		Sentences.get(0).process(date);
		Sentences.get(1).process(month);
		Sentences.get(2).process(date);
		Sentences.get(3).process(codeStock, date);
		Sentences.get(4).process(codeStock, date);
		Sentences.get(5).process(codeStock, date);
		Sentences.get(6).process(codeStock, date);
		Sentences.get(7).process(codeStock, date);
		Sentences.get(8).process(date);
		Sentences.get(9).process(date);
	}
	
	public static void main(String args[]) {
		ModelingData md = new ModelingData();
		Scanner sc = new Scanner(System.in);
		
		int month = sc.nextInt();
		String date = sc.next();
		String codeStock = sc.next();
		
		md.processData(date, month, codeStock);// xử lý dữ liệu theo ngày và tháng
		sc.close();
	}
	
	
	
	
	
}	
